package com.cg.web;

import java.io.IOException;
import java.sql.SQLException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.cg.dto.Register;
import com.cg.service.RegisterService;
import com.cg.service.RegisterServiceImpl;


@WebServlet("/SuccessServlet")
public class SuccessServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
	   Register reg=null;
	    RegisterService regService=null;
	    ServletConfig cg=null;
    public SuccessServlet() {
        super();
       
    }

	
	public void init(ServletConfig config) throws ServletException {
		
	}

	
	public void destroy() {
		// TODO Auto-generated method stub
	}

	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		doPost(request,response);
	}

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		 regService=new RegisterServiceImpl();
	        
	        String fnm=request.getParameter("fName");
	        String lnm=request.getParameter("lName");
	        String pwd=request.getParameter("txtPwd");
	        String gend=request.getParameter("gen");
	        String course[]=request.getParameterValues("selec");
	        String sk=String.join(",", course);
	        String place=request.getParameter("city");
	        
	        reg=new Register(fnm,lnm,pwd,gend,sk,place);
	        try
	        {
	            
	            int dataAdded=regService.getAllDetails(reg);
	            if(dataAdded==1)
	            {
	                RequestDispatcher rdSuccess=request.getRequestDispatcher("SuccessServlet");
	                rdSuccess.forward(request,response);
	            }
	            else
	            {
	                RequestDispatcher rdFailure=request.getRequestDispatcher("htmls/Failure.html");
	                rdFailure.forward(request,response);
	                
	            }
	        }
	        catch(SQLException e)
	        {
	            e.printStackTrace();
	        }
	    }
	}


