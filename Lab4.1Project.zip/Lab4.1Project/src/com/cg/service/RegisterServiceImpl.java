package com.cg.service;

import java.sql.SQLException;

import com.cg.dao.RegisterDao;
import com.cg.dao.RegisterDaoImpl;
import com.cg.dto.Register;

public class RegisterServiceImpl implements  RegisterService
{
	RegisterDao registerDao=null;
	public RegisterServiceImpl()
	{
		registerDao=new RegisterDaoImpl();
	}

	@Override
	public int getAllDetails(Register reg) throws SQLException 
	{
		
		return  registerDao.getAllDetails(reg);
	}
     
}
