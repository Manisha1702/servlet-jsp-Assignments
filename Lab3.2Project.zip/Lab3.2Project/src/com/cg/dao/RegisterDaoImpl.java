package com.cg.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;


import com.cg.dto.Register;
import com.cg.util.DBUtil;

public class RegisterDaoImpl implements RegisterDao
{
	Connection con=null;
    PreparedStatement pst=null;
    ResultSet rs=null; 
		@Override
		public int getAllDetails(Register reg) throws SQLException 
        {
        	con=DBUtil.getCon();
    		System.out.println("Got Connection : ");
            String insertQry="INSERT INTO RegisteredUsers(firstname,lastname,password,gender,skillset,city)VALUES(?,?,?,?,?,?)";
            int dataAdded=0;
    		try
    		{
    			con=DBUtil.getCon();
    			pst=con.prepareStatement(insertQry);
    			pst.setString(1,reg.getFirstName());
    			pst.setString(2,reg.getLastName());
    			pst.setString(3,reg.getPassword());
    			pst.setString(4,reg.getGender());
    			pst.setString(5,reg.getSkillset());
    			pst.setString(6, reg.getCity());
    			dataAdded=pst.executeUpdate();
    		}
    		catch (Exception e) 
    		{
    			e.printStackTrace();
    		}
        
		finally
		{
			try {
				pst.close();
				con.close();
			} 
			catch (Exception e) 
			{
				e.printStackTrace();
			}
		}
		return dataAdded;
	}
}
	
			
		